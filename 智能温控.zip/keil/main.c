#include <REGX52.H>
#include "Delay.h"
#include "Key.h"
#include "Nixie.h"
#include "Timer0.h"
#include "DS18B20.h"

/**
自动控制温度系统。 数码管前两位显示温度，第四位显示自动控制状态，0，1
按键控制手动，自动模式。开机为自动模式
当温度大于24时，自动模式开启，风扇会自动运行
**/


sbit Motor=P2^4;
sbit Buzzer=P3^1;

unsigned char Counter,Compare = 0;	//计数值和比较值，用于输出PWM
int Temp,Key,Auto = 1; 							// 接收温度，按键
int Temp_Warn = 24;				// 报警温度

void main()
{
	Timer0_Init();	
	Timer1_Init();
	Buzzer = 0;
	while(1)
	{
		Key = Get_Key();
		switch (Key)
		{
			case 1: if(Auto) Auto = 0;			// 切换模式，风扇速度清0
							else Auto = 1; 
							Compare = 0;		break;
			case 2: Compare = 0; break;
			case 3: Compare = 50; break;
			case 4: Compare = 100; break;
		}
		
		if(Temp > Temp_Warn)			// 大于报警温度，开启蜂鸣器
		{
			Buzzer = 1;
			if(Auto)	Compare = 100;	// 如果是自动，风扇开启		
				
		}
		else
		{
			Buzzer = 0;		
			if(Auto)	Compare = 0;
		}
	}
}

void Timer0_Routine() interrupt 1 
{
	TL0 = 0x9C;		//设置定时初值
	TH0 = 0xFF;		//设置定时初值
	Counter++;
	Counter%=100;	//计数值变化范围限制在0~99
	if(Counter<Compare)	//计数值小于比较值
	{
		Motor=1;		//输出1
	}
	else				//计数值大于比较值
	{
		Motor=0;		//输出0
	}
}

void Timer1_ISR(void) interrupt 3 {
    TH1 = 0x3C;  // 重装定时器初值
    TL1 = 0xB0;  // 对应100ms
		
		DS18B20_ConvertT();	//转换温度
		Temp=DS18B20_ReadT();	//读取温度
		
		Nixie(1,Temp/10);
		Nixie(2,Temp%10);
		Nixie(4,Auto);			// 显示自动控制状态
}
