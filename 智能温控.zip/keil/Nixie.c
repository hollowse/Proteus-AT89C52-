#include <REGX52.H>
#include "Delay.h"

//数码管段码表
unsigned char NixieTable[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};

/**
  * @brief  数码管显示
  * @param  Location 要显示的位置，范围：1~8
  * @param  Number 要显示的数字，范围：段码表索引范围
  * @retval 无
  */
void Nixie(unsigned char Location,Number)
{
	switch(Location)		//位码输出
	{
		case 1:P2_0=1;P2_1=0;P2_2=0;P2_3=0;break;
		case 2:P2_0=0;P2_1=1;P2_2=0;P2_3=0;break;
		case 3:P2_0=0;P2_1=0;P2_2=1;P2_3=0;break;
		case 4:P2_0=0;P2_1=0;P2_2=0;P2_3=1;break;
	}
	P0=NixieTable[Number];	//段码输出
	Delay(1);				//显示一段时间
	P2=0x00;				//段码清0，消影
}
