#include <REGX52.H>
#include "Delay.h"

sbit KEY0 = P1^0;		// 模式切换// 手动/自动
sbit KEY1 = P1^1;		// 电机停止
sbit KEY2 = P1^2;		// 50转速
sbit KEY3 = P1^3;		// 100转速

/**
  * @brief  获取独立按键键码
  * @param  无
  * @retval 按下按键的键码，范围：0~4，无按键按下时返回值为0
  */
unsigned char Get_Key()
{
	unsigned char KeyNumber=0;
	
	
	if(KEY0==0){Delay(20);while(KEY0==0);Delay(20);KeyNumber=1;}
	if(KEY1==0){Delay(20);while(KEY1==0);Delay(20);KeyNumber=2;}
	if(KEY2==0){Delay(20);while(KEY2==0);Delay(20);KeyNumber=3;}
	if(KEY3==0){Delay(20);while(KEY3==0);Delay(20);KeyNumber=4;}
	return KeyNumber;
}
